import java.io.IOException;

public class runMain {
    public static void main(String[]args) throws IOException {
        mainMenuGUI obj=new mainMenuGUI();
        obj.displayMenu();
        obj.pressButton();
        //resturant obj1=new resturant("hardees");
        //obj1.addFoodItems();
    }
}
